puts "Instalando Amanda"
`apt-get install amanda*`
`mkdir -p /amanda /etc/amanda`
`chown backup:backup -R /amanda /etc/amanda`
`mkdir -p /amanda/vtapes/slot{1,2,3,4}`
`mkdir -p /amanda/holding`
`mkdir -p /amanda/state/{curinfo,log,index}`
`mkdir -p /etc/amanda/MyConfig`
`touch /etc/amanda/MyConfig/amanda.conf`
`cp /root/Escritorio/programa/amanda.conf /etc/amanda/MyConfig/amanda.conf`
`touch /etc/amanda/MyConfig/disklist`
`echo localhost /etc simple-gnutar-local >> /etc/amanda/MyConfig/disklist``echo 0 18 * * * amanda /usr/sbin/amcheck -m MyConfig >> /etc/crontab``echo 15 3 * * * amanda /usr/sbin/amdump MyConfig >> /etc/crontab`
puts "Terminado."
